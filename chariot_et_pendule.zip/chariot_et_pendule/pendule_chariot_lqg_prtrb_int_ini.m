% Mod�lisation du syst�me
M=1;m=0.1;l=0.5;g=9.81;
k1=20;k2=100;
xinit=0.0;thetainit=0.0;

% Mod�le d'�tat du syst�me lin�aris� tangent
A=[0 0 1 0;0 0 0 1;0 m*g/M -k2/M 0;0 (M+m)*g/(M*l) -k2/(M*l) 0];
B=[0; 0; k1/M; k1/(M*l)];
C=[1 0 0 0;0 1 0 0];
D=zeros(2,1);

% mod�le �tendu (x,theta,xp,thetap,q)
% q est l'int�gration de x
Ai=[A zeros(4,1);1 0 0 0 0];Bi=[B;0];

% retour d'�tat LQR
QXU=diag([1e3 1e3 10 10 1e4 1]);
Ki=lqr(Ai,Bi,QXU(1:5,1:5),QXU(6,6));

% observateur
QWV=diag([100 100 100 100 1 1]);
pendulek=ss(A,[B eye(4)],C,zeros(2,5));
[~,L] = kalman(pendulek,QWV(1:4,1:4),QWV(5:6,5:6));
Aobs=A-L*C;Bobs=[B L];Cobs=eye(4);Dobs=zeros(4,3);